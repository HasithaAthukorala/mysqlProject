create procedure check_password_length(IN pass varchar(32))
  BEGIN
    IF CHAR_LENGTH(pass) != 32
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'password must be in md5 format';
    END IF;
  END;

