create trigger parts_before_insert_nominee
  before INSERT
  on Nominee
  for each row
  BEGIN
    CALL check_num(new.Phone);
  END;

