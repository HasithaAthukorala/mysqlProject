create procedure check_LoanInstallment(IN installmentAmount double)
  BEGIN
    IF installmentAmount < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'check constraint on interest failed!';
    END IF;
END;

