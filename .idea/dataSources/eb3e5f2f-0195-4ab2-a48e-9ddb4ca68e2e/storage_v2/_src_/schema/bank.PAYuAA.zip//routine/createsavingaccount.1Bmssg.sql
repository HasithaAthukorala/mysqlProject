create procedure createSavingAccount(IN accountId      varchar(20), IN CustomerId varchar(20),
                                     IN branchCode     varchar(20), IN accountBalance decimal(13, 2),
                                     IN NomineeId      varchar(20), IN accountType varchar(20))
  BEGIN
    # CHECK MINIMUM BALANCE
    DECLARE minimumBlance DECIMAL(13,2);
    SELECT MinimumBalance INTO minimumBlance FROM Interest WHERE Interest.accountType = accountType;
    IF minimumBlance >= accountBalance THEN
      START TRANSACTION ;
        INSERT INTO `Account` (`AccountId`, `CustomerId`, `branchCode`, `AccountBalance`, `NomineeId`)
        VALUES (accountId,CustomerId,branchCode,accountBalance,NomineeId);
        INSERT INTO `SavingsAccount` (`AccountId`,`noOfWithdrawals`,`accountType`)
        VALUES (accountId,0,accountType);
      COMMIT ;
    ELSE
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'ACCOUNT BALANCE IS LESS THAN MINIMUM BALANCE OR ACCOUNT TYPE IS INVALID';
    END IF ;
  END;

