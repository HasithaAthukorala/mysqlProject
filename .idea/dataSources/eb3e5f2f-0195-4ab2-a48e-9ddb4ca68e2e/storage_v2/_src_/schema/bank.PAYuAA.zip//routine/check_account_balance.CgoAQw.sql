create function check_account_balance(old_balance decimal(13, 2), transaction_amount decimal(13, 2))
  returns tinyint(1)
  BEGIN
    DECLARE remained_amount DECIMAL(13, 2);
    SET remained_amount = (old_balance - transaction_amount);

    IF remained_amount < 0
    THEN
      RETURN false;
    ELSE
      RETURN true;
    END IF;
  END;

