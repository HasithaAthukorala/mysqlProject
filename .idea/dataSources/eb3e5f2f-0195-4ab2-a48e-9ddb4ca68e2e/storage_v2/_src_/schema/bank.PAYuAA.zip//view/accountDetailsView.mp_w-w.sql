create view accountDetailsView as
  select `bank`.`Account`.`AccountId`      AS `AccountID`,
         `bank`.`Account`.`CustomerId`     AS `customerID`,
         `bank`.`Account`.`branchCode`     AS `branchCode`,
         `bank`.`Account`.`AccountBalance` AS `AccountBalance`,
         `bank`.`Account`.`NomineeId`      AS `NomineeId`
  from `bank`.`Account`;

