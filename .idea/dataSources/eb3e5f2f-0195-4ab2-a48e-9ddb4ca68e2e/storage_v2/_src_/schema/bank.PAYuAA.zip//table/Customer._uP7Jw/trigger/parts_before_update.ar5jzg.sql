create trigger parts_before_update
  before UPDATE
  on Customer
  for each row
  BEGIN
    CALL check_num(new.PhoneNumber);
  END;

