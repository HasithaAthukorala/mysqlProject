create trigger parts_before_insert_password
  before INSERT
  on UserLogin
  for each row
  BEGIN
    CALL check_password_length(new.passsword);
  END;

