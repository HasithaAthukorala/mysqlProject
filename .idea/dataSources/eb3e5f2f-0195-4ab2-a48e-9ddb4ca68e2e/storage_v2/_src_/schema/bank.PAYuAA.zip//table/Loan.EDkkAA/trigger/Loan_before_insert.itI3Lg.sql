create trigger Loan_before_insert
  before INSERT
  on Loan
  for each row
  BEGIN
    CALL check_Loan(new.loanAmount, new.numberOfInstallments, new.nextInstallment);
  END;

