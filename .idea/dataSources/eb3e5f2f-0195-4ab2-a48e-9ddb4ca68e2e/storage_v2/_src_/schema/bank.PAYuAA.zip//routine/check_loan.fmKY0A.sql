create procedure check_Loan(IN loanAmount double, IN numberOfInstallments int, IN nextInstallment double)
  BEGIN
    IF loanAmount < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'check constraint on loan amount failed!';
    END IF;
    IF numberOfInstallments < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'check constraint on number of installments failed!';
    END IF;
    IF nextInstallment < 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'check constraint on next installment failed!';
    END IF;
END;

