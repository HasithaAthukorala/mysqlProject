create trigger parts_before_update_password
  before UPDATE
  on UserLogin
  for each row
  BEGIN
    CALL check_password_length(new.passsword);
  END;

