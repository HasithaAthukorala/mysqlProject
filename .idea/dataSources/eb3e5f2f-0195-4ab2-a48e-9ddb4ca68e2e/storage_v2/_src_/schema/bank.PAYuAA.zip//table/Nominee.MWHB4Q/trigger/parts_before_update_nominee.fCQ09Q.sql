create trigger parts_before_update_nominee
  before UPDATE
  on Nominee
  for each row
  BEGIN
    CALL check_num(new.Phone);
  END;

