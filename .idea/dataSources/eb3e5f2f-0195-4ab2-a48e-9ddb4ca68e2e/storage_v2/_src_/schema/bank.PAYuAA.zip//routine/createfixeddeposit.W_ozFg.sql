create procedure createFixedDeposit(IN FDid   varchar(20), IN AccountId varchar(20), IN typeId varchar(20),
                                    IN amount decimal(13, 2))
  BEGIN
    DECLARE nextInterestDate DATETIME;
    SET nextInterestDate = DATE_ADD(CURDATE(), INTERVAL 30 DAY);
    IF amount > 0 THEN
      START TRANSACTION;
        INSERT INTO FixedDeposit(`FDid`,`AccountId`,`typeId`,`amount`,`nextInterestDate`)
        VALUES (FDid,AccountId,typeId,amount,nextInterestDate);
      COMMIT;
    ELSE
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'FIXED DEPOSIT AMOUNT MUST BE GREATER THAN 0';
    END IF ;
  END;

