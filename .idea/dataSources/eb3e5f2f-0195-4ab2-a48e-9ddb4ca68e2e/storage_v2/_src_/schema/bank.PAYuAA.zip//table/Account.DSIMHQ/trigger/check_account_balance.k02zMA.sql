create trigger check_account_balance
  before INSERT
  on Account
  for each row
  BEGIN
    CALL check_balance(new.AccountBalance, new.AccountId);
  END;

