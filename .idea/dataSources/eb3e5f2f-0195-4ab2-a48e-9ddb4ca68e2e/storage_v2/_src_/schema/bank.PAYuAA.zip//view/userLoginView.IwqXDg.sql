create view userLoginView as
  select `bank`.`UserLogin`.`username`  AS `username`,
         `bank`.`UserLogin`.`passsword` AS `passsword`,
         `bank`.`UserLogin`.`role`      AS `role`
  from `bank`.`UserLogin`;

