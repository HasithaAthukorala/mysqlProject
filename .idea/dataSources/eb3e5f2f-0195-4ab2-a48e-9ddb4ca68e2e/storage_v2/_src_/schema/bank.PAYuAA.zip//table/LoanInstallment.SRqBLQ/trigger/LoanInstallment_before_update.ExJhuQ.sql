create trigger LoanInstallment_before_update
  before UPDATE
  on LoanInstallment
  for each row
  BEGIN
    CALL check_LoanInstallment(new.installmentAmount);
  END;

