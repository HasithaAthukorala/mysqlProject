create trigger parts_before_insert
  before INSERT
  on Customer
  for each row
  BEGIN
    CALL check_num(new.PhoneNumber);
  END;

