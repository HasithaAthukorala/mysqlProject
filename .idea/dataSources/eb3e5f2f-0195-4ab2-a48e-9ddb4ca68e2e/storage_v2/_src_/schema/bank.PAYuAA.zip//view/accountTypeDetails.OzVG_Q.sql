create view accountTypeDetails as
  select `bank`.`Interest`.`accountType` AS `accountType`
  from `bank`.`Interest`;

