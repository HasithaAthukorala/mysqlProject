create view branchDetailView as
  select `bank`.`Branch`.`branchCode` AS `branchCode`, `bank`.`Branch`.`branchName` AS `branchName`
  from `bank`.`Branch`;

