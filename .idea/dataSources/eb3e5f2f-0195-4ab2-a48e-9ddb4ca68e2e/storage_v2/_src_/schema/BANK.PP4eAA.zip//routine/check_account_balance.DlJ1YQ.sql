create function check_account_balance(old_balance float(100, 4), transaction_amount float(100, 4))
  returns tinyint(1)
  BEGIN
    DECLARE remained_amount FLOAT(100, 4);
    SET remained_amount = (old_balance - transaction_amount);

    IF remained_amount < 0
    THEN
      RETURN false;
    ELSE
      RETURN true;
    END IF;
  END;

