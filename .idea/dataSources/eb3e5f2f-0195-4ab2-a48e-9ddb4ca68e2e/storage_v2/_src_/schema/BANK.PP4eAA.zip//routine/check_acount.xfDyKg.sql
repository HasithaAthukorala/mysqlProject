create function check_acount(id varchar(20), nic varchar(12))
  returns tinyint(1)
  BEGIN
DECLARE result boolean;
DECLARE newID VARCHAR(20);

SELECT COUNT(CustomerId) into newID from IndividualCustomer WHERE CustomerId=id AND NIC=nic;

IF newID>0 then
  SET result = TRUE ;
ELSE
  SET result = FALSE ;
end if;


RETURN result;

END;

