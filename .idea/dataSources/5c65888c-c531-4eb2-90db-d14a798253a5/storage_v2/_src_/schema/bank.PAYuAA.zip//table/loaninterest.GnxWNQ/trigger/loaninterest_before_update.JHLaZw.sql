create trigger LoanInterest_before_update
  before UPDATE
  on loaninterest
  for each row
  BEGIN
    CALL check_LoanInterest(new.interest, new.installmentDuration);
  END;

