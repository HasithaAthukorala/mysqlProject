create trigger LoanInstallment_before_insert
  before INSERT
  on loaninstallment
  for each row
  BEGIN
    CALL check_LoanInstallment(new.installmentAmount);
  END;

