create view pendingloanstatus as
  select `bank`.`loanapplicaton`.`applicationID`     AS `applicationID`,
         `bank`.`loanapplicaton`.`applicationStatus` AS `applicationStatus`
  from `bank`.`loanapplicaton`;

