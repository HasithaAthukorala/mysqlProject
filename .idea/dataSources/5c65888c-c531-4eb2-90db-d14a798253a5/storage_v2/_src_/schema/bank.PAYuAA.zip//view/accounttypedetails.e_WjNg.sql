create view accounttypedetails as
  select `bank`.`interest`.`accountType` AS `accountType`
  from `bank`.`interest`;

