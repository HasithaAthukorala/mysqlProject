create definer = root@localhost event fixedDepositInterestEvent
  on schedule
    every '1' DAY
      starts '2018-11-28 11:11:21'
  enable
do
  BEGIN
      START TRANSACTION ;
      UPDATE account
        SET AccountBalance = (SELECT AccountBalance * (1 + (interest/100)) FROM FixedDeposit LEFT JOIN FDType T on FixedDeposit.typeId = T.typeId where Account.AccountId = FixedDeposit.AccountId)
        WHERE AccountId IN (
            SELECT AccountId FROM FixedDeposit WHERE nextInterestDate = CURDATE()
            );
      UPDATE FixedDeposit
          SET nextInterestDate = DATE_ADD(CURDATE(), INTERVAL 30 DAY)
          WHERE nextInterestDate = curdate();
      COMMIT ;
END;

