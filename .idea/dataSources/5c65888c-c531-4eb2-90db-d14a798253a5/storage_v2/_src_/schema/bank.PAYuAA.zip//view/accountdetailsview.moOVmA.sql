create view accountdetailsview as
  select `bank`.`account`.`AccountId`      AS `AccountID`,
         `bank`.`account`.`CustomerId`     AS `customerID`,
         `bank`.`account`.`branchCode`     AS `branchCode`,
         `bank`.`account`.`AccountBalance` AS `AccountBalance`,
         `bank`.`account`.`NomineeId`      AS `NomineeId`
  from `bank`.`account`;

