create procedure check_num(IN phone varchar(20))
  BEGIN
    IF CHAR_LENGTH(phone) != 10
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'length of the phone number must be equal to 10';
    END IF;
  END;

