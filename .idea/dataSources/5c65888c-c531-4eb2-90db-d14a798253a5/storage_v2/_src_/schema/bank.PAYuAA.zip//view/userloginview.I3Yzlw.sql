create view userloginview as
  select `bank`.`userlogin`.`username`  AS `username`,
         `bank`.`userlogin`.`passsword` AS `passsword`,
         `bank`.`userlogin`.`role`      AS `role`
  from `bank`.`userlogin`;

