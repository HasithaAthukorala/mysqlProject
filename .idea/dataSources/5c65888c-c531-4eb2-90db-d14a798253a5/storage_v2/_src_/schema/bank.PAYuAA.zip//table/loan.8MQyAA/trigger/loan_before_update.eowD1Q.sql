create trigger Loan_before_update
  before UPDATE
  on loan
  for each row
  BEGIN
    CALL check_Loan(new.loanAmount, new.numberOfInstallments, new.nextInstallment);
  END;

