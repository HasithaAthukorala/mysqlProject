create trigger LoanInstallment_before_update
  before UPDATE
  on loaninstallment
  for each row
  BEGIN
    CALL check_LoanInstallment(new.installmentAmount);
  END;

