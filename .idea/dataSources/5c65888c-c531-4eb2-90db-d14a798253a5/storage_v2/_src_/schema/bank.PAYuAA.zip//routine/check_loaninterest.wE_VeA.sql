create procedure check_LoanInterest(IN interest float, IN installmentDuration int)
  BEGIN
    IF interest < 0
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'check constraint on interest failed!';
    END IF;
    IF installmentDuration < 0
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'check constraint on installmentDuration failed!';
    END IF;
  END;

