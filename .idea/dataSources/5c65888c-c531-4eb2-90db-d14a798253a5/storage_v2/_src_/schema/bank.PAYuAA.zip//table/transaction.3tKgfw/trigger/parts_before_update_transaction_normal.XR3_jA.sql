create trigger parts_before_update_transaction_normal
  before UPDATE
  on transaction
  for each row
  BEGIN
    DECLARE old_balance DECIMAL(13, 2);
    SELECT AccountBalance INTO old_balance FROM `Account` WHERE AccountId = NEW.fromAccountID;
    IF check_account_balance(old_balance, NEW.Amount) = true
    THEN
      UPDATE `Account` SET AccountBalance = (old_balance - NEW.Amount) WHERE AccountId = NEW.fromAccountID;
      UPDATE `Account` SET AccountBalance = (old_balance + NEW.Amount) WHERE AccountId = NEW.toAccountID;
    ELSE
      SIGNAL SQLSTATE '45002'
      SET MESSAGE_TEXT = 'Account balance is not enough to transfer';
    END IF;
  END;

