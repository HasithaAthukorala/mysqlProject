create view branchdetailview as
  select `bank`.`branch`.`branchCode` AS `branchCode`, `bank`.`branch`.`branchName` AS `branchName`
  from `bank`.`branch`;

