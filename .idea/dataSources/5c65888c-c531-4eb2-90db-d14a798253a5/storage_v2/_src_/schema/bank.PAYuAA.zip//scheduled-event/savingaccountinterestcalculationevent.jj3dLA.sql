create definer = root@localhost event savingAccountInterestCalculationEvent
  on schedule
    every '1' MONTH
      starts '2018-12-01 00:00:00'
  enable
do
  BEGIN
      START TRANSACTION ;
      UPDATE account
        SET AccountBalance = (SELECT AccountBalance * (1 + (interest/100)) FROM SavingsAccount left join interest on SavingsAccount.accountType = Interest.accountType where Account.AccountId = SavingsAccount.AccountId)
        WHERE AccountId IN (
            SELECT AccountId FROM savingsaccount
            );
      UPDATE SavingsAccount
          SET noOfWithdrawals = 0;
      COMMIT ;
END;

