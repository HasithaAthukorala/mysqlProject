create trigger parts_before_insert
  before INSERT
  on customer
  for each row
  BEGIN
    CALL check_num(new.PhoneNumber);
  END;

