create procedure approveLoanApplication(IN `_applicationID` int)
  BEGIN
    START TRANSACTION ;
      UPDATE pendingLoanStatus
          SET applicationStatus = 1 WHERE applicationID = _applicationID;
      INSERT INTO Loan (customerID, loanType, loanAmount, startDate, endDate, nextInstallmentDate, nextInstallment, numberOfInstallments, applicationID)
      SELECT customerID,loanType,loanAmount,startDate,endDate,nextInstallmentDate,nextInstallment,numberOfInstallments,applicationID FROM loanapplicaton;
    COMMIT ;
  END;

