create procedure check_balance(IN AccBalance float, IN AccId varchar(20))
  BEGIN
    DECLARE account_type VARCHAR(20);
    DECLARE minbal FLOAT(100,4);
    SET account_type = (SELECT accountType from SavingsAccount  where AccountId = AccId);
    SET minbal = (SELECT MinimumBalance from interest where accountType = account_type);
    IF AccBalance  < 0
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'check constraint on interest failed!';
    END IF;

    IF minbal > AccBalance
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Account must keep the minimal balance';
    END IF;
  END;

