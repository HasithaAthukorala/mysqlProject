create function getCustomerID(nic varchar(12))
  returns varchar(20)
  BEGIN
DECLARE id VARCHAR(20);
SELECT CustomerId into id FROM IndividualCustomer WHERE IndividualCustomer.NIC=nic;
RETURN id;

END;

